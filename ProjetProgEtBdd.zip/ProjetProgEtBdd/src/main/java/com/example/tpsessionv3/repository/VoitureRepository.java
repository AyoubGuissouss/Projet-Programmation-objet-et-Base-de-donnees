package com.example.tpsessionv3.repository;

import com.example.tpsessionv3.model.Voiture;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface VoitureRepository extends JpaRepository<Voiture,Integer> {

    @Query("SELECT v FROM  Voiture v where v.isRented=true")
    public List<Voiture> listRented();

    @Query("select v FROM Voiture v where v.price <= :price")
    public List<Voiture> listByPrice(@Param("price") double price);

    @Query("select v FROM Voiture v where v.mileage <= :mileage")
    public List<Voiture> listByMileage(@Param("mileage") double mileage);

    @Query("select v FROM Voiture v where v.year <= :year")
    public List<Voiture> listByYear(@Param("year") int year);
}
