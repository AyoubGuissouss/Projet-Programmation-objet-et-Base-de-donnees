package com.example.tpsessionv3.configuration;

import com.example.tpsessionv3.model.Voiture;
import com.example.tpsessionv3.repository.VoitureRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class VoitureConfig {

    //@Bean
    CommandLineRunner commandLineRunner(VoitureRepository voitureRepository){
        return args -> {

            Voiture voiture1 = new Voiture(2018,100000,false,"Hyundai","Elantra",18000);
            Voiture voiture2 = new Voiture(2019,80000,false,"Hyundai","Tucson",28000);
            Voiture voiture3 = new Voiture(2017,75000,false,"Toyota","Corolla",18500);
            Voiture voiture4 = new Voiture(2022,20000,false,"Toyota","Rav4",45000);
            Voiture voiture5 = new Voiture(2012,140000,false,"Bmw","535xi",15000);
            Voiture voiture6 = new Voiture(2013,170000,false,"Audi","A5",13000);
            Voiture voiture7 = new Voiture(2017,70000,false,"Mercedes","C300",32000);
            Voiture voiture8 = new Voiture(2020,45000,false,"Kia","Sorento",42000);
            Voiture voiture9 = new Voiture(2012,156000,false,"Acura","TL",12000);
            Voiture voiture10 = new Voiture(2021,21000,false,"Porshe","Macan",55000);

            voitureRepository.saveAll(
                    List.of(voiture1, voiture2, voiture3, voiture4, voiture5, voiture6, voiture7, voiture8, voiture9, voiture10)
            );

        };
    }
}
