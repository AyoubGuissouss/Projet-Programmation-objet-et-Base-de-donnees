package com.example.tpsessionv3.controlleur;

import com.example.tpsessionv3.model.Voiture;
import com.example.tpsessionv3.service.VoitureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;



@RestController
public class VoitureControlleur {

    @Autowired
    private VoitureService voitureService;

    @GetMapping("/")
    public String welcome(){
        return "Bienvenue dans notre site de gestion de location de voitures";
    }

    @GetMapping("/cars")
    public List<Voiture> getListCars() {
        return voitureService.listAll();
    }

    @GetMapping("/rentedCars")
    public List<Voiture> getRentedCars() {
        return voitureService.listRented();
    }

    @GetMapping("/car/{id}")
    public Voiture getCarById(@PathVariable Integer id){
        return voitureService.get(id);
    }

    @GetMapping("/carsByYear/{year}")
    public List<Voiture> getCarsByYear(@PathVariable Integer year){
        return voitureService.listByYear(year);
    }

    @GetMapping("/carsByPrice/{price}")
    public List<Voiture> getCarsByPrice(@PathVariable double price){
        return voitureService.listByPrice(price);
    }

    @GetMapping("/carsByMileage/{mileage}")
    public List<Voiture> getCarsByMileage(@PathVariable double mileage){
        return voitureService.listByMileage(mileage);
    }


}
