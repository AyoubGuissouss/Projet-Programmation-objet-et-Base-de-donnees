package com.example.tpsessionv3.service;

import com.example.tpsessionv3.model.Client;
import com.example.tpsessionv3.model.Reservation;
import com.example.tpsessionv3.model.Voiture;
import com.example.tpsessionv3.repository.ReservationRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ReservationService {

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private ClientService clientService;

    @Autowired
    private VoitureService voitureService;

    public List<Reservation> listAllReservations(){
        return reservationRepository.findAll();
    }

    public void deleteReservation(Integer id){
        boolean exist = reservationRepository.existsById(id);
        if(exist){
            Reservation reservation = reservationRepository.findById(id).get();
            Voiture voiture = reservation.getVoiture();
            voiture.setRented(false);
            reservationRepository.deleteById(id);
        }else{
            System.out.println("Auncune reservation avec l'Id: " + id);
        }
    }

    public void save(Integer carId,Integer clientId,String dateReservation,String dateCirculation,String dateRetour){
        Client client = clientService.get(clientId);
        List<Voiture> voitureList = voitureService.listAll();
        boolean existe = false;
        for(Voiture tmp : voitureList){
            if(tmp.getId().equals(carId)){
                Voiture voiture = voitureService.get(carId);
                if(voiture.isRented() == false){
                    Reservation reservation = new Reservation(dateReservation,dateCirculation,dateRetour,voiture,client);
                    voiture.setRented(true);
                    reservationRepository.save(reservation);
                    existe = true;
                }else{
                    System.out.println("Cette voiture est déja loué!");
                }
            }
        }
        if(!existe){
            System.out.println("Aucune voiture avec cette Id!");
        }
    }
}
