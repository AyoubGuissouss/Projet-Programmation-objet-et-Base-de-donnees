package com.example.tpsessionv3.service;

import com.example.tpsessionv3.model.Client;
import com.example.tpsessionv3.repository.ClientRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ClientService {

    @Autowired
    private ClientRepository clientRepository;

    public void save(Client client){
        clientRepository.save(client);
    }

    public Client get(Integer id){
        return clientRepository.findById(id).get();
    }

    public List<Client> getAllClients(){
        return clientRepository.findAll();
    }

    public void deleteClient(Integer id){
        boolean exist = clientRepository.existsById(id);
        if(exist){
            clientRepository.deleteById(id);
        }else{
            System.out.println("Auncun client avec l'Id: " + id);
        }
    }

    public void updateClient(Integer id, String nom, String prenom, String email){
        boolean exist = clientRepository.existsById(id);
        if(exist){
            Client client = clientRepository.findById(id).get();
            client.setNom(nom);
            client.setPrenom(prenom);
            client.setEmail(email);
        }else{
            System.out.println("Auncun client avec l'Id: " + id);
        }
    }
}
