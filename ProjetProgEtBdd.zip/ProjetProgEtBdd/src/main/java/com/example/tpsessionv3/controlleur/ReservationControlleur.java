package com.example.tpsessionv3.controlleur;

import com.example.tpsessionv3.model.Client;
import com.example.tpsessionv3.model.Reservation;
import com.example.tpsessionv3.model.Voiture;
import com.example.tpsessionv3.service.ClientService;
import com.example.tpsessionv3.service.ReservationService;
import com.example.tpsessionv3.service.VoitureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class ReservationControlleur {

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private ClientService clientService;

    @Autowired
    private VoitureService voitureService;

    @GetMapping("/reservations")
    public List<Reservation> listReservations(){
        return reservationService.listAllReservations();
    }

    @PostMapping("/reserveCar/{carId}")
    public void reserveCar(@PathVariable Integer carId, @RequestParam Integer clientId, @RequestParam String dateReservation, @RequestParam String dateCirculation, @RequestParam String dateRetour){
            reservationService.save(carId,clientId,dateReservation,dateCirculation,dateRetour);
    }

    @DeleteMapping("/deleteReservation/{id}")
    public void deleteReservation(@PathVariable Integer id){
        reservationService.deleteReservation(id);
    }
}
