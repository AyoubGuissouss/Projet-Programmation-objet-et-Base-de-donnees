package com.example.tpsessionv3.model;


import jakarta.persistence.*;

import java.util.Optional;

@Entity
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String dateReservation;
    private String dateCirculation;
    private String dateRetour;

    @OneToOne
    @JoinColumn(name = "voiture_FK")
    private Voiture voiture;

    @ManyToOne
    @JoinColumn(name = "client_id_FK")
    private Client client;

    //Constructeurs
    public Reservation() {
    }

    public Reservation(String dateReservation, String dateCirculation, String dateRetour, Voiture voiture, Client client) {
        this.dateReservation = dateReservation;
        this.dateCirculation = dateCirculation;
        this.dateRetour = dateRetour;
        this.voiture = voiture;
        this.client = client;
    }

    //Getter and Setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDateReservation() {
        return dateReservation;
    }

    public void setDateReservation(String dateReservation) {
        this.dateReservation = dateReservation;
    }

    public String getDateCirculation() {
        return dateCirculation;
    }

    public void setDateCirculation(String dateCirculation) {
        this.dateCirculation = dateCirculation;
    }

    public String getDateRetour() {
        return dateRetour;
    }

    public void setDateRetour(String dateRetour) {
        this.dateRetour = dateRetour;
    }

    public Voiture getVoiture() {
        return voiture;
    }

    public void setVoiture(Voiture voiture) {
        this.voiture = voiture;
    }

    //ToString

    @Override
    public String toString() {
        return "Reservation{" +
                "id=" + id +
                ", dateReservation='" + dateReservation + '\'' +
                ", dateCirculation='" + dateCirculation + '\'' +
                ", dateRetour='" + dateRetour + '\'' +
                ", voiture=" + voiture +
                ", client=" + client +
                '}';
    }
}
