package com.example.tpsessionv3.repository;

import com.example.tpsessionv3.model.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservationRepository extends JpaRepository<Reservation,Integer> {
}
