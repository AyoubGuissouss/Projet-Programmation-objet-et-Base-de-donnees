package com.example.tpsessionv3.controlleur;

import com.example.tpsessionv3.model.Client;
import com.example.tpsessionv3.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ClientControlleur {

    @Autowired
    private ClientService clientService;

    @GetMapping("/clients")
    public List<Client> listAllClients(){
        return clientService.getAllClients();
    }

    @PostMapping("/addClient")
    public void addClient(@RequestParam String nom, @RequestParam String prenom, @RequestParam String email){
        try {
            Client client = new Client(nom, prenom, email);
            clientService.save(client);
        }catch(Exception e){
            System.out.println("Données saisies non valides, recommencez!");
        }
    }

    @DeleteMapping("/deleteClient/{id}")
    public void deleteClient(@PathVariable Integer id){
        clientService.deleteClient(id);
    }

    @PutMapping("/updateClient/{id}")
    public void updateClient(@PathVariable Integer id, @RequestParam String nom, @RequestParam String prenom, @RequestParam String email){
        try {
            clientService.updateClient(id, nom, prenom, email);
        }catch(Exception e){
            System.out.println("Données saisies non valides, recommencez!");
        }
    }
}
