package com.example.tpsessionv3.model;

import jakarta.persistence.*;

@Entity
public class Voiture {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="voiture_PK")
    private Integer id;
    private Integer year;
    private double mileage;
    private boolean isRented;
    private String company, model;
    private double price;

    //Constructeurs
    public Voiture() {
    }

    public Voiture(Integer year, double mileage, boolean isRented, String company, String model, double price) {
        this.year = year;
        this.mileage = mileage;
        this.isRented = isRented;
        this.company = company;
        this.model = model;
        this.price = price;
    }

    //Getter and Setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public double getMileage() {
        return mileage;
    }

    public void setMileage(double mileage) {
        this.mileage = mileage;
    }

    public boolean isRented() {
        return isRented;
    }

    public void setRented(boolean rented) {
        isRented = rented;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    //ToString

    @Override
    public String toString() {
        return "voiture{" +
                "id=" + id +
                ", year=" + year +
                ", mileage=" + mileage +
                ", isRented=" + isRented +
                ", company='" + company + '\'' +
                ", model='" + model + '\'' +
                ", price=" + price +
                '}';
    }
}
