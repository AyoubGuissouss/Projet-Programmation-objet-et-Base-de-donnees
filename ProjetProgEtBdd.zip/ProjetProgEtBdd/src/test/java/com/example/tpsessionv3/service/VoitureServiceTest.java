package com.example.tpsessionv3.service;

import com.example.tpsessionv3.model.Voiture;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class VoitureServiceTest {

    @Autowired
    private VoitureService voitureService;

    @BeforeEach
    void setUp() {
        System.out.println("@BeforeEach");
        voitureService.viderTable();
        voitureService.insertIntoTable();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void testListAllRetourneListeDeTaille10() {
        System.out.println("testListAllRetourneListeDeTaille10");
        List<Voiture> listVoiture = voitureService.listAll();
        assertEquals(10,listVoiture.size());
    }

    @Test
    void testListRentedRetourneListeDeTaille1() {
        System.out.println("testListRentedRetourneListeDeTaille1");
        List<Voiture> voitureList = voitureService.listRented();
        assertEquals(1,voitureList.size());
    }

    @Test
    void testListByPriceRetourneListTaille5() {
        System.out.println("testListByPriceRetourneListTaille5");
        List<Voiture> voitureList = voitureService.listByPrice(20000);
        assertEquals(5,voitureList.size());
    }

    @Test
    void testListByYearRetourneListTaille3() {
        System.out.println("testListByYearRetourneListTaille3");
        List<Voiture> voitureList = voitureService.listByYear(2015);
        assertEquals(3,voitureList.size());
    }

    @Test
    void testListByMileageRetourneListTaille7() {
        System.out.println("testListByMileageRetourneListTaille7");
        List<Voiture> voitureList = voitureService.listByMileage(100000);
        assertEquals(7,voitureList.size());
    }
}