package com.example.tpsessionv3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpSessionV2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
